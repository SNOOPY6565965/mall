// vant组件按需导入
import Vue from 'vue'

import { Radio, RadioGroup, checkbox, checkboxGroup, Dialog, ActionSheet, Rate, Sidebar, SidebarItem, Icon, Grid, GridItem, Lazyload, Swipe, SwipeItem, Search, Toast, NavBar, Tabbar, TabbarItem } from 'vant'
Vue.use(Radio)
Vue.use(RadioGroup)
Vue.use(checkbox)
Vue.use(checkboxGroup)
Vue.use(Dialog)
Vue.use(ActionSheet)
Vue.use(Rate)
Vue.use(SidebarItem)
Vue.use(Sidebar)
Vue.use(Icon)
Vue.use(Grid)
Vue.use(GridItem)
Vue.use(Lazyload)
Vue.use(SwipeItem)
Vue.use(Swipe)
Vue.use(Search)
Vue.use(Toast)
Vue.use(NavBar)
Vue.use(TabbarItem)
Vue.use(Tabbar)
